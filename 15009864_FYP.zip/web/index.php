<?php
	$servername = "localhost";
	$username = "mali101";
	$password = "mali101";
	$dbname = "mali101";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	session_start();
	if(@$_SESSION['username']){
    if(isset($_POST['submit'])) {
                        //  To make it more secure
        $_SESSION['username'] = htmlentities($_POST['username']);
		
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Ali's Accommodation</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tenements Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a href="index.html"><span>Ali's</span>Accommodation</a></h1>
			</div>
			<div class="agile_header_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
<center> <h1> Welcome, <?php echo $_SESSION['username']; ?> </h1> </center>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			</div>
		</div>
	</div>
<!-- header -->
<!-- banner -->
	<div class="banner">
		<div class="container"> 
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="link-effect-12">
						<ul class="nav navbar-nav w3_agile_nav">
							<li class="active"><a href="index.php"><span>Home</span></a></li>
							<li><a href="properties.php"><span>Properties</span></a></li>
							<li><a href="about.html"><span>About Us</span></a></li>
							<li><a href="mail.php"><span>Contact</span></a></li>
							<li><a href="logout.php"><span>Log Out</span></a></li>
						</ul>
						<div class="w3_agileits_search_form">
						<form id="searchbar" action="" method="GET">
						<input id="searchbar1" type="text" name="search" placeholder="Search Properties..." />
						</form>
						</div>
					</nav>
				</div>
			</nav>
		</div>
	</div>
<!-- //banner -->
<!-- banner-bottom -->
	<div class="banner-bottom">
		<div class="container">
			<div class="col-md-6 w3layouts_banner_bottom_left">
				<h3></h3>
			</div>
			<div class="clearfix"> </div>
			<div class="w3_banner_bottom_pos">
				<form action="#" method="post">
					<h2>Find a property</h2>
					<div class="agile_book_section_top">
						<select onchange="change_country(this.value)" required="">
							<option value="">Filter By Keywords</option>
							<option value="">Property By Id</option>
							<option value="">Location</option>         
							<option value="">Type</option>
							<option value="">Status</option>
							<option value="">Price</option>
						</select>
					</div>
					<div class="agileits_w3layouts_book_section_single">
						<div class="w3_agileits_section_room">
							<select onchange="change_country(this.value)" required="">
								<option value="">Any Type</option>
								<option value="">Appartment</option>         
								<option value="">Detached Property</option>
								<option value="">Semi Detached</option>
								<option value="">Flat</option>
								<option value="">House</option>
								<option value="">Terraced Property</option>
							</select>
						</div>	
						<div class="w3_agileits_section_room">
							<select onchange="change_country(this.value)" required="">
								<option value="">Any Location</option>
								<option value="">Hyde Park</option>         
								<option value="">Headingley</option>
								<option value="">Burley Park</option>
								<option value="">Kirkstall</option>
							</select>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="bed">
						<h4>Bed rooms</h4>
						<input type="number" class="text_box" value="3" min="1">
					</div>
					<div class="clearfix"></div>
					<div class="wthree_range_slider">
						<h4>Price range</h4>
						<div id="slider-range"></div>	
						<input type="text" id="amount" style="border: 0;" />
							
					</div>
					<input type="submit" value="Find properties">
				</form>
			</div>
		</div>
	</div>
<!-- //banner-bottom -->
<!-- services -->
	<div class="services">
		<div class="container">
			<div class="w3layouts_header">
				<p><span><i class="fa fa-key" aria-hidden="true"></i></span></p>
				<h5>Properties<span> To Rent</span></h5>
			</div>
			<div class="w3_services_grids">
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid">
						<div class="agile_services_grid1_sub">
							<p>£99 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos">
							<i class="fa fa-user-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>35 Spring Bank Crescent, Headingley, Four Bed, Leeds</h3>
						<h4 class="w3_agileits_service">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid2">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub1">
							<p>£90 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos1">
							<i class="fa fa-bath" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>236 Kirkstall Lane, Headingley, Nine Bed, Leeds</h3>
						<h4 class="w3_agileits_service2">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid1">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub">
							<p>£95 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>20 The Poplars, Headingley, Three Bed, Leeds</h3>
						<h4 class="w3_agileits_service1">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-6 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid3">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub2">
							<p>£82 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos2">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>8 Newport Road, Headingley, Two Bed, Leeds</h3>
						<h4 class="w3_agileits_service3">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-6 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid4">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub3">
							<p>£82 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos3">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>3 Granby Place, Headingley, Three Beds, Leeds</h3>
						<h4 class="w3_agileits_service4">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //services -->
<!-- footer -->
	<div class="newsletter">
		<div class="container">
			<div class="w3layouts_header w3_agile_head">
				<p><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span></p>
				<h5>Subscribe to our <span>Newsletter</span></h5>
			</div>
			<div class="w3layouts_skills_grids w3l_newsletter_form">
				<form action="#" method="post">
					<input type="text" name="Name" placeholder="Name" required="">
					<input type="email" name="Email" placeholder="Email" required="">
					<input type="submit" value="Send">
				</form>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- gauge-meter -->
	<script src="js/jquery.gauge.js"></script>
	<script>
		$(document).ready(function (){
			$("#gauge1").gauge(30,{color: "#fb5710",unit: " %",type: "halfcircle"});
			$("#gauge2").gauge(70, {color: "#a821e7", unit: " %",type: "halfcircle"});
			$("#gauge3").gauge(75, {color: "#fbb810",unit: " %",type: "halfcircle"});
			$("#gauge4").gauge(90, {color: "#21d0e7",unit: " %",type: "halfcircle"});
		});
	</script>
<!-- //gauge-meter -->
<!-- range -->
	<script type="text/javascript" src="js/jquery-ui.js"></script>		
	<script type='text/javascript'>//<![CDATA[ 
		$(window).load(function(){
		 $( "#slider-range" ).slider({
					range: true,
					min: 0,
					max: 900,
					values: [ 50, 600 ],
					slide: function( event, ui ) {  $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
					}
		 });
		$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );

		});//]]>  
	</script>
<!-- //range -->
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smooth-scrolling -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>
<?php
}else {
echo"You must be logged in";
header('Refresh: 1; URL=http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Login.php');
}
?>