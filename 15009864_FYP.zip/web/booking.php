<?php
	include("db.php");	
if(@$_SESSION['username']){
?>

 </div>

<section id="section">

<div align="center">

<form id="bookingsystem" action="bookingprocess.php" method="post">

<fieldset id="bookingaccommodation">
<legend>Accommodation:</legend>
<label for="firstname"> First Name: <input type="text" name="firstname" id="firstname" required autofocus placeholder="FirstName..."><br><br>
<label for="firstname"> Last Name: <input type="text" name="lastname" id="lastname" required autofocus placeholder="LastName..."><br><br>
<label for="email"> Email: <input type="text" name="email" id="email" required placeholder="Email..." ><br><br>
<label for="phone"> Phone: <input type="tel" name="phone" id="phone" required placeholder="Phone number...">
</fieldset>

<br>

<fieldset id="bookingdetails">

<label for="accommodation">Accommodation: </label>
<input name="accommodation" type="text" placeholder="Accommodation"/>


<label for="bookdate">Starting date: </label>
<input type="date" name="bookdate" min="2016-04-25">
<br>
<br>

<label for="starttime">start time: </label>
<select name="starttime"> 
	<option value="8am - 10am">8am - 10am</option>
    <option value="10am - 12pm">10am - 12pm</option>
    <option value="12pm - 2pm">12pm - 2pm</option>
    <option value="2pm - 4pm">2pm - 4pm</option>   
	<option value="4pm - 6pm">4pm - 6pm</option>
</select>
<br>
<br>


<input id="submitbutton" type="submit"/>
</fieldset>
</form>
</div>


</section>

<article id="article" style="height:70%;">

</article>

</body>
</html>
<?php
}else {
echo"You must be logged in";
header('Refresh: 1; URL=http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Login.php');
}
?>