<?php 
set_error_handler(function($errno, $errstr) {
    return strpos($errstr, 'mysql_') === 0;
}, E_DEPRECATED);  

$result="";


$host="localhost"; // Host name 
$username="mali101"; // Mysql username 
$password="mali101"; // Mysql password 
$db_name="mali101"; // Database name 
$tbl_name="Users"; // Table name

mysql_connect ("$host","$username","$password") or die ("could not connect");

mysql_select_db("$db_name")or die("cannot select DB");
session_start();
$ID=$_REQUEST['ID'];
$query = "DELETE FROM Users WHERE ID='$ID'"; 
$result = mysql_query($query) or die ( mysql_error());
header("Location: viewuserdetails.php"); 
 ?>