<?php
session_start();
if(@$_SESSION['username']){
$result="";
ob_start();
$host="localhost"; // Host name 
$username="mali101"; // Mysql username 
$password="mali101"; // Mysql password 
$db_name="mali101"; // Database name 
$tbl_name="Booking"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$accommodation=$_POST['accommodation'];
$bookdate=$_POST['bookdate'];
$starttime=$_POST['starttime'];


// Insert data into mysql 
$sql="INSERT INTO Booking(firstname, lastname, email, phone, accommodation, bookdate, starttime)VALUES('$firstname', '$lastname','$email', '$phone', '$accommodation', '$bookdate', '$starttime')";
$result=mysql_query($sql);

if($result){
	header("location: booking.php");
}
else {
echo "ERROR";
}
//code to send email
		 $to = 'mansoor1997@hotmail.co.uk '.$email.'';
		 $message = 'Thank you for making your booking '.$firstname.' '.$lastname.' '.$phone.' You have made a booking for '.$accommodation.' at '.$starttime.' for '.$bookdate.' 
		 Keep thie email as proof that you have successfully booked the accommodation.'; 
         $header = "From:".$email."\r\n";
         
                 
         $retval = mail ($to,$firstname,$message,$header);
?> 


<?php 
// close connection 
mysql_close();
?>
<?php
}else {
echo"You must be logged in";
header('Refresh: 1; URL=http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Login.php');
}
?>