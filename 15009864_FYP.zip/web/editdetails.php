<?php 
require('db.php');
$ID=$_REQUEST['ID'];
$query = "DELETE FROM users WHERE ID='$ID'"; 
$result = mysql_query($query) or die ( mysql_error());
header("Location: viewuserdetails.php"); 
 ?>