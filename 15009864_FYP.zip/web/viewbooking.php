<!DOCTYPE html>
<html>
<head>
	<title>Ali's Accommodation </title>
    <!--Mobile specific meta, used to scale down website-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 
    <!--css-->
    <link rel="stylesheet" href="css/styles.css">

<div>
</head>

<body id="body">

<header id="header">
<font color="white">

</font>

</header>

<nav id="nav">
<section id="section">
<center> <h1> BookingDetails </h1> </center>

<div id="bookingdetails">
<table width="100%" border="2" style="border-collapse:collapse;">
<thead><tr><th><strong>Firstname</strong></th><th><strong>Lastname</strong></th><th><strong>Email</strong></th><th><strong>Phone</strong></th><th><strong>Accommodation</strong>
</th><th><strong>BookDate</strong></th><th><strong>StartTime</strong></th></tr></thead>
<tbody>
<?php
include 'db.php';
$query ="SELECT * FROM Booking ORDER BY bookdate DESC";
$result = mysqli_query($conn, $query);
while($row = mysqli_fetch_assoc($result)) {
	echo "<tr>";
	echo "<td>".$row['firstname']."</td>";
	echo "<td>".$row['lastname']."</td>";
	echo "<td>".$row['email']."</td>";
	echo "<td>".$row['phone']."</td>";
	echo "<td>".$row['accommodation']."</td>";
	echo "<td>".$row['bookdate']."</td>";
	echo "<td>".$row['starttime']."</td>";
}
?>
<form action ="http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Adminmainpage.php">
	<p><button class="btn btn-default">Back</button></p>
	</form>
</body>
</html>