<?php
$servername = "localhost";
$username = "mali101";
$password = "mali101";
$dbname = "mali101";
$conn = mysqli_connect($servername, $username, $password, $dbname);
session_start();
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$ID=$_REQUEST['ID'];
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$email = $_REQUEST['email'];
$firstname =$_REQUEST['firstname'];
$lastname =$_REQUEST['lastname'];

$update="update Users set username='".$username."', password='".$password."',email='".$email."', firstname='".$firstname."', lastname='".$lastname."', 
where ID='".$ID."'";
mysql_query($update) or die(mysql_error());
$status = "Record Updated Successfully. </br></br><a href='mydetails.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Ali's Accommodation</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tenements Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a href="index.html"><span>Ali's</span>Accommodation</a></h1>
			</div>
			<div class="agile_header_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			</div>
		</div>
	</div>
<div>
<form id="Adminmainpage.php" name="form" method="post" action="" enctype="multipart/form-data"> 
<input type="hidden" name="new" value="1" />
<tr><td valign="top"><label for="ID">ID:</label></td><td valign="top"><br>
<p><input name="usersID" readonly="readonly" value="<?php echo $row['ID'];?>" /></p>
<tr><td valign="top"><label for="username">Username:</label></td><td valign="top"><br>
<p><input type="text" name="username" readonly="readonly" value="<?php echo $row['username'];?>" /></p>
<tr><td valign="top"><label for="password">Password:</label></td><td valign="top"><br>
<p><input type="password" name="password" required value="<?php echo $row['password'];?>" /></p>
<tr><td valign="top"><label for="email">Email:</label></td><td valign="top"><br>
<p><input type="text" name="email" required value="<?php echo $row['email'];?>" /></p>
<tr><td valign="top"><label for="firstname">First Name:</label></td><td valign="top"><br>
<p><input type="text" name="firstname" required value="<?php echo $row['firstname'];?>" /></p>
<tr><td valign="top"><label for="lastname">Last Name:</label></td><td valign="top"><br>
<p><input type="text" name="lastname" required value="<?php echo $row['lastname'];?>" /></p>
<br><br>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
</div>
</body>
</html>