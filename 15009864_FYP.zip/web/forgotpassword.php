<?php
$servername = "localhost";
$username = "mali101";
$password = "mali101";
$dbname = "mali101";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn) {
die ("connection failed" . mysqli_connect_error());
}
session_start();
if ($_SERVER ['REQUEST_METHOD'] == 'POST') {
	$email = $_POST["email"];
	$sql = "SELECT * FROM Users WHERE email='$email'";
}

	if ($sql->num_rows ==0)
	{
		$_SESSION['message']= "A user with the email provided does not exist";
	}
	else {
		$user = $sql->fetch_assoc();
		
		$email = $user['email'];
		firstname = $user ['first_name'];
		
		$SESSION['message'] =<p>"A reset password link has been sent to  
	}