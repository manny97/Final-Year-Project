<!DOCTYPE html>
	<?php
	$servername = "localhost";
	$username = "mali101";
	$password = "mali101";
	$dbname = "mali101";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	session_start();
	if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    $username = $_POST["username"];
	$password = $_POST["password"];

	  if ($username == '' || $password == ''){

		$msg = "You must enter all fields";

	}else{

		$query = "SELECT * FROM Admin WHERE username = '$username' AND password = '$password'";
	   
	   $result = mysqli_query($conn,$query);
	   $row = mysqli_fetch_array($result,MYSQL_ASSOC);
   
   $count = mysqli_num_rows($result);
 

		if ($query == 0){

			echo "Could not successfully run query";

			}

	if ($count== 1){
	echo "Correct Login Credentials";
	$_SESSION['username']= $username;
	header('Location: Adminmainpage.php');


		  

		}else{
		$msg = "Username and Password do not match";
		header('Location: Admin_login.php');
	}
	}
}
?>
<html lang="en">
<head>
<title>Ali's Accommodation</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tenements Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a href="index.html"><span>Ali's</span>Accommodation</a></h1>
			</div>
			<div class="agile_header_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			</div>
		</div>
	</div>
<!-- header -->
<!-- banner -->
	<div class="banner">
		<div class="container"> 
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="link-effect-12">
						<ul class="nav navbar-nav w3_agile_nav">
							<li class="active"><a href="index.html"><span>Home</span></a></li>
							
						</ul>
					</nav>
				</div>
			</nav>
		</div>
	</div>
		
    <table align="center" bgcolor="#CCCCCC" border="0" cellpadding="0"
    cellspacing="1" width="300">
        <tr>
            <td>
                <form method="post" name="">
                    <table bgcolor="#FFFFFF" border="0" cellpadding="3"
                    cellspacing="1" width="100%">
                        <tr>
                            <td align="center" colspan="3"><strong>
                           Admin Login</strong></td>
                        </tr>
                        <tr>
                            <td width="78">Username</td>
                            <td width="600">:</td>
                            <td width="294"><input id="username" name=
                            "username" type="text"></td>
                        </tr>
						<tr>
                            <td>Password</td>
                            <td>:</td>
                            <td><input id="password" name="password" type=
                            "password"></td>
                        </tr>
					    <tr>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>
							<input name="submit" type="submit" value="Login"> 
						</td>
                        </tr>
                    </table>
                </form>
            </td>
        </tr>
    </table>
	</body>
	</html>
