<?php
	$servername = "localhost";
	$username = "mali101";
	$password = "mali101";
	$dbname = "mali101";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	session_start();
?>