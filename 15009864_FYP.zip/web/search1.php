<?php
$servername = "localhost";
$username = "mali101";
$password = "mali101";
$dbname = "mali101";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if(!$conn) {
die ("connection failed" . mysqli_connect_error());
}
//if we got something through $_POST
if(isset($_POST['search'])){
	$searchq = $_POST['search'];
	$query = "SELECT * FROM  properties WHERE name like '%$searchq%'"; 
	$count = mysqli_num_rows($query);
	if($count == 0){
		$output = '<h2>No result found!</h2>';
	}else{
		while($row = mysqli_fetch_array($query)){
		$name = $row['name']; 
				$output .= '<h2>'.$query.'</h2><br>';
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Search</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tenements Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a href="index.html"><span>Ali's</span>Accommodation</a></h1>
			</div>
			<div class="agile_header_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			</div>
		</div>
	</div>
<!-- header -->
<!-- banner -->
	<div class="banner1">
		<div class="container"> 
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="link-effect-12">
						<ul class="nav navbar-nav w3_agile_nav">
							<li><a href="index.html"><span>Home</span></a></li>
							<li class="active"><a href="properties.html"><span>Properties</span></a></li>
							<li><a href="about.html"><span>About Us</span></a></li>
							<li><a href="mail.php"><span>Mail Us</span></a></li>
						</ul>
						<div class="w3_agileits_search_form">

							<form action="search1.php" method="post<?php echo $_SERVER['PHP_SELF']; ?>">
								
								<input type="search" name="Search" placeholder="Search" required="">
								<input type="submit" value=" "> 
							</form>
						</div>
					</nav>
				</div>
			</nav>
			<div class="agileits_properties_banner">
				<h2>Properties</h2>
			</div>
		</div>
	</div>
<!-- //banner -->
<!-- properties -->
	<div class="services">
		<div class="container">
			<div class="w3layouts_header">
				<p><span><i class="fa fa-building-o" aria-hidden="true"></i></span></p>
				<h5>Properties <span>To Rent</span></h5>
			</div>
			<div class="w3_services_grids">
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid">
						<div class="agile_services_grid1_sub">
							<p>£99 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos">
							<i class="fa fa-user-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>35 Spring Bank Crescent, Headingley, Four Bed, Leeds</h3>
						<h4 class="w3_agileits_service">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid2">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub1">
							<p>£90 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos1">
							<i class="fa fa-bath" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>236 Kirkstall Lane, Headingley, Nine Bed, Leeds</h3>
						<h4 class="w3_agileits_service2">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid1">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub">
							<p>£95 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>20 The Poplars, Headingley, Three Bed, Leeds</h3>
						<h4 class="w3_agileits_service1">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-6 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid3">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub2">
							<p>£82 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos2">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>8 Newport Road, Headingley, Two Bed, Leeds</h3>
						<h4 class="w3_agileits_service3">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-6 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid4">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub3">
							<p>£82 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos3">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>3 Granby Place, Headingley, Three Beds, Leeds</h3>
						<h4 class="w3_agileits_service4">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid5">
						<div class="agile_services_grid1_sub">
							<p>£140 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos">
							<i class="fa fa-user-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>165a Royal park Terrace, Hyde Park, One Bed, Leeds</h3>
						<h4 class="w3_agileits_service">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid6">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub1">
							<p>£120 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos1">
							<i class="fa fa-bath" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>105 Victoria Road, Hyde Park, Six Bed, Leeds</h3>
						<h4 class="w3_agileits_service2">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="col-md-4 w3l_services_grid">
					<div class="w3ls_services_grid agileits_services_grid7">
						<div class="agile_services_grid1_sub agileits_w3layouts_ser_sub">
							<p>£75 pppw</p>
						</div>
						<div class="agileinfo_services_grid_pos agile_services_grid_pos">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
					</div>
					<div class="wthree_service_text">
						<h3>Beechwood Avenue, Burley, Four Bed, Leeds </h3>
						<h4 class="w3_agileits_service1">Ali's Accommodation</h4>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	</body>
	</html>