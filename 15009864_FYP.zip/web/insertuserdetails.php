<?php
include('db.php');

$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$firstname =$_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$query="insert into Users(`firstname`,`lastname`,`username`,`email`,`password`)values('$firstname','$lastname','$username','$email','$password')";
mysqli_query($conn,$query) or die(mysqli_connect_error());
$status = "New Record Created Successfully.</br></br><a href='viewuserdetails.php'>View Inserted Record</a>";
}
?>


<div>
<form id="login1" name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input class='textbox' name='firstname' type='text' id='firstname' Required="true" placeholder="Firstname..." ><br><br>
<input class='textbox' name='lastname' type='text' id='lastname' Required="true" placeholder="Lastname..." ><br><br>
<input class="textbox" name="username" type="text" id="username" Required="true" placeholder="Username..." ><br><br>
<input class="textbox" name="email" type="text" id='email' Required="true" placeholder="Email..." ><br><br>
<input class='textbox' name='password' type='password' id='password' Required="true" placeholder="Password..." ><br><br>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
