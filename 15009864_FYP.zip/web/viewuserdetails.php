<?php 
set_error_handler(function($errno, $errstr) {
    return strpos($errstr, 'mysql_') === 0;
}, E_DEPRECATED);  

$result="";


$host="localhost"; // Host name 
$username="mali101"; // Mysql username 
$password="mali101"; // Mysql password 
$db_name="mali101"; // Database name 


mysql_connect ("$host","$username","$password") or die ("could not connect");

mysql_select_db("$db_name")or die("cannot select DB");
session_start();
if(@$_SESSION['username']){
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ali's Accommodation </title>
    <!--Mobile specific meta, used to scale down website-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 
    <!--css-->
    <link rel="stylesheet" href="css/styles.css">

<div>
</head>

<body id="body">

<header id="header">
<font color="white">

</font>

</header>

<nav id="nav">
<section id="section">
<center> <h1> User Details </h1> </center>

<div id="viewrecords">
<table width="100%" border="2" style="border-collapse:collapse;">
<thead><tr><th><strong>User No</strong></th><th><strong>Username</strong></th><th><strong>Password</strong></th><th><strong>Email</strong></th><th><strong>Firstname</strong>
</th><th><strong>Lastname</strong></th><th><strong>Delete</strong></th></tr></thead>
<tbody>
<?php

$count=1;
$query="Select * from Users ORDER BY ID ;";
$result = mysql_query($query);
while($row = mysql_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td><td align="center"><?php echo $row["username"]; ?></td><td align="center"><?php echo $row["password"]; ?></td>
<td align="center"><?php echo $row["email"]; ?></td><td align="center"><?php echo $row["firstname"]; ?></td><td align="center"><?php echo $row["lastname"]; ?></td>
<td align="center"><a href="deletedetails.php?ID=<?php echo $row["ID"]; ?>">Delete</a></td></tr>
<?php $count++; } ?>
</tbody>
</table>
</div>

</section>

<article id="article" style="height:60%;">

</article>

<form action ="http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Adminmainpage.php">
	<p><button class="btn btn-default">Back</button></p>
	</form>

</body>
</html>
<?php
}else {
echo"You must be logged in";
header('Refresh: 1; URL=http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Admin_login.php');
}
?>