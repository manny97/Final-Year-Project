<?php
//Include DB configuration file
include 'db.php';
include 'session.php';

//Set variables for paypal form
$paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
$paypalID = 'mali101@bradford.ac.uk'; //Business Email

?>

<head>
	<title>Reset</title>
    <!--Mobile specific meta, used to scale down website-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 
    <!--css-->
    <link rel="stylesheet" href="css/styles.css">

	
    <!-- Favicon in address bar-->
    <link rel="shortcut icon" href="images/webicon.jpg">
<div>

<a href="../index.html"><img src="images/ufclogo.png" class="responsive-image"></a> 
</div>
</head>

<body id="body">

<header id="header">
         <!-- Full Navigation Bar turns to burger menu-->	
	<ul class="topnav" id="myTopnav">
	<li><a href="properties.php"><span>Properties</span></a></li>
	<li><a href="about.html"><span>About Us</span></a></li>
	<li><a href="mail.php"><span>Mail US</span></a></li>
	<li><a href="logout.php"><span>Log Out</span></a></li>
      

    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
  </li>
</ul>

</header>
 </div>
 <a href="index.php"><img src="images/register/backbutton.png"/></a>
<nav id="nav">
</nav>
<?php
    //Fetch products from the database
    $results = $db->query("SELECT * FROM users");
    while($row = $results->fetch_assoc()){
?>

    <img src="images/<?php echo $row['image']; ?>"/> <br>
    Name: <?php echo $row['name']; ?> <br>
    Price: <?php echo $row['price']; ?> 
    <form action="<?php echo $paypalURL; ?>" method="post"> 

        <!-- Identify business so that you can collect the payments. -->
        <input type="hidden" name="business" value="<?php echo $paypalID; ?>">
        
        <!-- Buy Now button. -->
        <input type="hidden" name="cmd" value="_xclick">
        
        <!-- Details about the item that buyers will purchase. -->
        <input type="hidden" name="item_name" value="<?php echo $row['name']; ?>">
        <input type="hidden" name="item_number" value="<?php echo $row['id']; ?>">
        <input type="hidden" name="amount" value="<?php echo $row['price']; ?>">
        <input type="hidden" name="currency_code" value="GBP">
        
        <!-- Specify URLs -->
        <input type='hidden' name='return' value='http://lamp.scim.brad.ac.uk:50844/UFCTest/Userlogin/success.php'>
		<input type='hidden' name='cancel_return' value='http://lamp.scim.brad.ac.uk:50844/UFCTest/Userlogin/cancel.php'>
        
        <!-- Display the payment button. -->
        <input type="image" name="submit" border="0"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
        <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" > 
    </form>