<?php
	$servername = "localhost";
	$username = "mali101";
	$password = "mali101";
	$dbname = "mali101";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	session_start();
	if(@$_SESSION['username']){
    if(isset($_POST['submit'])) {
                        //  To make it more secure
        $_SESSION['username'] = htmlentities($_POST['username']);
		
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Ali's Accommodation</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tenements Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a href="index.html"><span>Ali's</span>Accommodation</a></h1>
			</div>
			<div class="agile_header_social">
				<ul class="agileits_social_list">
					<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<center> <h1> Welcome, <?php echo $_SESSION['username']; ?> </h1> </center>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			</div>
		</div>
	</div>
<!-- header -->
<!-- banner -->
	<div class="banner">
		<div class="container"> 
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="link-effect-12">
						<ul class="nav navbar-nav w3_agile_nav">
							<li class="active"><a href="index.html"><span>Home</span></a></li>
						</ul>						
		</div><!--/Center Column-->
		<div class="row">
				<article class="col-xs-12">
					<h1>Admin Page</h1>
					<p>View User</p>
					<form action = "viewuserdetails.php">
					<p><button class="btn btn-default">View User</button></p>
					</form>	
					<p>Add User</p>
					<form action = "insertuserdetails.php">
					<p><button class="btn btn-default">Add User</button></p>
					</form>	
					<p>View Booking</p>
					<form action ="viewbooking.php">
					<p><button class="btn btn-default">View Booking</button></p>
					</form>	
				</article>
			</div>
			<hr>
			<div class="row">
				<article class="col-xs-12">
					<h1>Log Out</h1>
					<p>Click the button below to log out.</p>
			<form id="logout" action = "admin_logout.php" method ="POST">		
					<p><input type ="submit" class="btn btn-default" value ="Logout" /></p>
			</form>
				</article>
			</div>
			<hr>      
			<div class="row">
				<article class="col-xs-12">
					<h1>Send Mail</h1>
					<p>Use the button below to send emails to all users</p>				
				<p><button class="btn btn-default">Email Sent</button></p>
			</form>
				</article>
			</div>
			<hr>
</body>
</html>
<?php
}else {
echo"You must be logged in";
header('Refresh: 1; URL=http://lamp.scim.brad.ac.uk:50811/FYP/AliAccommodation/web/Admin_login.php');
}
?>